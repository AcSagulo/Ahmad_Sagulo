﻿Public Class Form1




    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click




        Dim overOne As Double = 0
        If Double.TryParse(burstOne.Text, overOne) Then
            TextBox1.Text = "P1"
            ProgressBar1.Value = 100

        Else
            MessageBox.Show("'" & burstOne.Text & "'P1 is not a valid input")
            ProgressBar1.Value = 0
        End If



        Dim overTwo As Double = 0
        If Double.TryParse(burstTwo.Text, overTwo) Then
            TextBox2.Text = "P2"
            TextBox1.Text = "P1"
        Else
            MessageBox.Show("'" & burstTwo.Text & "'P2 is not a valid input")
            ProgressBar1.Value = 0
        End If



        Dim overThree As Double = 0
        If Double.TryParse(burstThree.Text, overThree) Then
            TextBox3.Text = "P3"
            TextBox1.Text = "P1"
        Else
            MessageBox.Show("'" & burstThree.Text & "'P3 is not a valid input")
            ProgressBar1.Value = 0
        End If

        Dim overFour As Double = 0
        If Double.TryParse(burstFour.Text, overFour) Then
            TextBox4.Text = "P4"
            TextBox1.Text = "P1"
        Else
            MessageBox.Show("'" & burstFour.Text & "'P4 is not a valid input")
            ProgressBar1.Value = 0
        End If



        Dim turnoverTotal As Double = 0
        Dim turnoverAverage As Double = 0
        turnoverTotal = overTwo + overThree + overFour

        totalturn.Text = burstTwo.Text + " + " + burstThree.Text + " + " + burstFour.Text + " = "
        average.Text = turnoverTotal
        turnoverAverage = turnoverTotal / 4
        TextBox9.Text = turnoverAverage

        overTwo = overTwo + overOne
        overThree = overTwo + overThree
        overFour = overThree + overFour


        turnOne.Text = overOne

        turnTwo.Text = overTwo

        turnThree.Text = overThree

        turnFour.Text = overFour

        TextBox5.Text = 0
        TextBox6.Text = overOne
        TextBox7.Text = overTwo
        TextBox8.Text = overThree

        TextBox10.Text = 0 + overOne + overTwo + overThree
        TextBox11.Text = 0 + overOne + overTwo + overThree / 3

    End Sub


End Class
